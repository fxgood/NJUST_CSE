#include "tt.h"
int main()
{
	//test1();
	//test4();
	
	//test5();
	//test6();
	//test7();
	//test8();
	//test9();
	//test10();
	//newtest10();

	//test11();
	//test12();
	//test13();
	//test14();
	//test15();
	//test16();
	//test17();
	//test18();
	//newtest18();
	//test19();
	//test20();

	//test21();
	//test22();
	//test23();
	//newtest23();
	//test24();
	//test25();
	//test26();
	//test27();
	//test28();
	//test29();

	//test30();
	//newtest30();
	//test31();
	//test32();
	//newtest32();
	//test33();
	//test34();
	//newtest34();
	//test35();
	// test36();
	//newtest36();
	//test37();
	//test38();
	//test39();
	//test40();
	//test41();
	//test42();
	//test43();
	//test44();
	//newtest44();
	test45();
	//newtest45();
	//test46();
	//test58();
	//test59();
	//test60();
	//newtest60();
	//mynewtest60();
	//mynewtest60_4();
	//test61();
	//mycount();
	//zqcstring();
	return 0;
}