#include "tt.h"

void test1()
{
	double y;
	int x,m;
	for (y=1;y>=-1;y-=0.1)
	{
		m=acos(y)*10;
		for (x=1;x<m;x++)
			cout<<" ";
		cout<<"*";
		for (;x<62-m;x++)
			cout<<" ";
		cout<<"*"<<endl;
	}
}
//------------------------------//
void test4()
{
 	vector<double>v;
	cout<<"����ʮ������:"<<endl;
	double dd,result=0;
	double max=0;
	double min=100;
	double avg;
	for (int i=0;i<10;i++)
	{
		cin>>dd;
		result+=dd;
		v.push_back(dd);
		if (dd>max)
			max=dd;
		if (dd<min)
			min=dd;
	}
	cout<<"ȥ����߷�:"<<max<<endl;
	cout<<"ȥ����ͷ�:"<<min<<endl;
	result=result-max-min;
	avg=result/8;
	cout<<"���÷�:"<<avg<<endl;


	max=abs(v[0]-avg);
	min=abs(v[0]-avg);
	int maxi=0;
	int mini=0;
	double temp;
	for ( i=0;i<10;i++)
	{
		temp=abs(v[i]-avg);
		if (temp>max)
		{
			max=temp;
			maxi=i;
		}
		if (temp<min)
		{
			min=temp;
			mini=i;
		}
	}
	cout<<"��ӽ���ֵ�ķ�����"<<mini<<"������"<<v[mini]<<endl;
	cout<<"��Զ���ֵ�ķ�����"<<maxi<<"������"<<v[maxi]<<endl;
}
//------------------------------//
void test5()
{
	int n=555555;
	for(int i=999;i>99;i--)
		if (n%i==0)
		{
			cout<<"���Լ��Ϊ:"<<i<<endl;
			break;
		}
}
//------------------------------//
void test6()
{
	int x,y;
	cin>>x>>y;//����x��y�η�����λ����
	int n=1;
	for (int i=0;i<y;i++)
	{
		n=n*x%1000;
	}
	cout<<n<<endl;
}
//------------------------------//
void test7()//����n�Ľ׳˺����ж�����
{
	int n;
	cin>>n;
	int num=0;
	int temp;
	for (int i=1;i<=n;i++)
	{
		temp=i;
		while(temp%5==0)
		{
			num++;
			temp/=5;
		}
	}
	cout<<"num:"<<num<<endl;
}
//------------------------------//
void test8()
{
	int num=0;
	for (int i=1;i<=5;i++)
	{
		for (int j=1;j<=5;j++)
		{
			if (j!=i)
			{
				for (int k=1;k<=5;k++)
				{
					if (k!=i && k!=j)
					{
						cout<<i<<" "<<j<<" "<<k<<endl;
						num++;
					}
				}
			}
		}
	}
	cout<<"total:"<<num<<endl;
}
//------------------------------//
int jiecheng(int n)
{
	if (n<=1)
		return 1;
	else
		return n*jiecheng(n-1);
}
int fun(int m,int n)
{
	if (m==0 && n==0)
		return 1;
	return jiecheng(m)/jiecheng(n)/jiecheng(m-n);
}
void test9()
{
	int n;
	cin>>n;
	for (int i=1;i<=n+1;i++)
	{
		for (int j=0;j<2*(n-1)-i;j++)
			cout<<setw(2)<<" ";
		for (j=0;j<i;j++)
			cout<<setw(2)<<fun(i-1,j)<<setw(2)<<" ";
		cout<<endl;
	}
}
//------------------------------//
void newfun(int n)
{
	if (n/2)
	{
		newfun(n/2);
		cout<<n%2;
	}
	else
		cout<<n%2;
}
void test10()
{
	int n;
	cin>>n;
	newfun(n);
	cout<<endl;
}
//------------------------------//
void printb(int x,int n)
{
	if (n>0)
	{
		char ch;
		unsigned int dd=(unsigned)(x&(1<<(n-1)));
		ch='0'+(dd>>(n-1));
		cout<<ch;
		printb(x,n-1);
	}
}
void newtest10()
{
	
	int x;
	cin>>x;
	printb(x,sizeof(int)*8);
	cout<<endl;
}
//------------------------------//
int IsLeap(int n)
{
	if (n%400==0|| n%4==0 && n%100!=0)
		return 1;
	return 0;
}
void test11()
{
	int months[12]={31,28,31,30,31,30,31,31,30,31,30,31};
	int year,month,day;
	cin>>year>>month>>day;
	int sum=0;
	for (int i=1990;i<year;i++)
	{
		if (IsLeap(i))
			sum+=366;
		else
			sum+=365;
	}
	for (i=1;i<month;i++)
	{
		if (i==2 && IsLeap(year))
			sum+=29;
		else
			sum+=months[i-1];
	}
	sum+=day;
	if (sum%5<=3 && sum%5>0)
		cout<<"���㣡"<<endl;
	else
		cout<<"ɹ����"<<endl;
	
}
//------------------------------//
void test12()
{
	int n=0;
	for (int i=(int)sqrt(1000)+1;i<100;i++)
	{
		n=i*i;
		if ((n/1000==n/100%10)&&(n%10==n/10%10))
		{
			cout<<i<<"*"<<i<<"="<<i*i<<endl;
			break;
		}
	}
}
//------------------------------//
void test13()
{
	double  dd=0;
	for (int i=0;i<5;i++)
	{
		dd=(dd+1000)/(0.0063*12+1);
	}
	cout<<dd<<endl;
}
//------------------------------//
void test14()
{
	int i1,i2,i3,i5,i8;
	int n1,n2,n3,n5,n8;
	float max=0,temp;
	for (i8=0;i8<3;i8++)
		for (i5=0;i5<=(20-8*i8)/5;i5++)
			for (i3=0;i3<=(20-8*i8-5*i5)/3;i3++)
				for (i2=0;i2<=(20-8*i8-5*i5-3*i3)/2;i2++)
				{
					i1=20-8*i8-5*i5-3*i3-2*i2;
					temp=2000*pow(1+0.0063*12,(double)i1)*pow(1+2*0.0066*12,(double)i2)*pow(1+3*0.0069*12,(double)i3)*pow(1+5*0.0075*12,(double)i5)*pow(1+8*0.0084*12,(double)i8);
					if (temp>max)
					{
						max=temp;
						n1=i1;n2=i2;n3=i3;
						n5=i5;n8=i8;
					}
				}
	cout<<"max="<<max<<endl;
	cout<<"n1="<<n1<<"  n2="<<n2<<endl;
	cout<<"n3="<<n3<<"  n5="<<n5<<endl;
	cout<<"n8="<<n8<<endl;
}
//------------------------------//
void test15()
{
	int x,y;
	for (int i=1;;i++)
	{
		x=5*i+1;
		for (int j=0;j<4;j++)
		{
			y=5*x;
			if (y%4==0)
			{
				y=y/4+1;
			}
			else
				break;
			x=y;
		}
		if (j==4)
		{
			cout<<y<<endl;
			return;
		}
	}
}
//------------------------------//
void test16()
{
	int x=11,y;
	for (int i=4;i>0;i--)
	{
		y=(1+x*(i+1))/i;
		x=y;
	}
	cout<<y<<endl;
}
//------------------------------//
void test17()
{
	int a[3][3]={0};
	int count=0;
	for (int i=1;i<4;i++)
	{
		//��һ����
		a[0][0]=i;
		a[0][1]=(3.5-i)*2;
		a[0][2]=7-a[0][0]-a[0][1];
		//�ڶ�����
		for (int j=1;j<4;j++)
		{
			
				a[1][0]=j;
				a[1][1]=(3.5-j)*2;
				a[1][2]=7-a[1][0]-a[1][1];
				if(a[1][0]>=a[0][0] && a[1][1]>=a[0][1])
				{
					//��������
					a[2][0]=7-a[0][0]-a[1][0];
					a[2][1]=7-a[0][1]-a[1][1];
					a[2][2]=7-a[0][2]-a[1][2];
					
					if (a[2][0]*1+a[2][1]*0.5==3.5  && a[2][0]+a[2][1]+a[2][2]==7 && a[2][0]>0 && a[2][1]>0 && a[2][2]>0)
					{
						count++;
						for (int ii=0;ii<3;ii++)
						{
							for (int jj=0;jj<3;jj++)
								cout<<a[ii][jj]<<" ";
							cout<<endl;
						}
						cout<<endl;
					}	
				}
		}	
	}
	cout<<count<<endl;
}
//------------------------------//
void test18()
{
	int count=0;
	for (int i=10006;i<99996;i=i+10)
	{
		if (i%3==0)
		{
			count++;
		}
	}
	cout<<"total:"<<count<<endl;
}
void newtest18()
{
	int count=0;
	int temp=0;
	int sum;
	for (int i=100;i<1000;i++)
	{
		temp=i;
		sum=0;
		while (temp)
		{
			sum+=temp%10;
			temp/=10;
		}
		if (sum==5)
		{
			cout<<i<<" ";
			count++;
		}
	}
	cout<<"\ntotal:"<<count<<endl;
}
//------------------------------//
void test19()
{
	int m,n;
	for (int i=0;;i++)
	{
		m=((8*i+7)*8+1)*8+1;
		n=(2*i*17+15)*17+4;
		if (m==n)
		{
			cout<<m<<endl;
			break;
		}
	}
}
//------------------------------//
void test20()
{
	for (int a=1;a<7;a++)
		for (int b=0;b<7;b++)
			for (int c=0;c<7;c++)
				if(a*49+b*7+c==c*81+b*9+a)
					cout<<a*49+b*7+c<<endl;
}
//------------------------------//
void test21()
{
	int n;
	int sum;
	for (int i=1000;i<1112;i++)
	{
		sum=0;
		n=9*i;
		while (n)
		{
			sum=sum*10+n%10;
			n/=10;
		}
		if (sum==i)
		{
			cout<<i<<endl;
		}
	}
}
//------------------------------//
void test22()
{
	int temp,result;
	for (int i=1993;i>0;i--)
	{
		temp=i;
		result=0;
		while (temp)
		{
			result=result*2+(temp)%2;
			temp/=2;
		}
		if (result==i)
		{
			cout<<i<<endl;
			break;
		}
	}
}
//------------------------------//
void test23()
{
	int a,b,c;
	for (int i=100;i<1000;i++)
		for (int j=100;j<1000;j++)
			if (sqrt(i)==(int)sqrt(i) && sqrt(j)==(int)sqrt(j))
			{
				a=i/100*10+j/100;
				b=(i/10%10)*10+(j/10%10);
				c=(i%10)*10+(j%10);
				if (sqrt(a)==(int)sqrt(a) && sqrt(b)==(int)sqrt(b) && sqrt(c)==(int)sqrt(c) )
				{
					cout<<i<<" "<<j<<endl;
					break;
				}
			}	
}
void newtest23()
{
	for (int i=100;i<1000;i++)
	{
		if (jiecheng(i/100)+jiecheng(i/10%10)+jiecheng(i%10)==i)
		{
			cout<<i<<endl;
		}
	}
}
//------------------------------//
void test24()
{
	int temp,result,num=0;
	for (int i=1;i<1000;i++)
	{
		temp=i;
		result=0;
		while (temp)
		{
			result+=pow(temp%10,3);
			temp/=10;
		}
		if (result==i)
		{
			cout<<i<<" ";
			num++;
			if (num%5==0)
				cout<<endl;
		}	
	}
	cout<<"total:"<<num<<endl;	
}
//------------------------------//
void test25()
{
	int num=0;
	for (int i=1;i<1000;i++)
	{
		int result=0;
		for (int j=1;j<i;j++)
		{
			if (i%j==0)
			{
				result+=j;
			}
		}
		if (i==result)
		{
			cout<<i<<" ";
			num++;
			if (num%5==0)
				cout<<endl;
		}
	}
	cout<<"\ntotal:"<<num<<endl;
}
//------------------------------//
void test26()
{
	int num=0;
	for (int i=1;i<3000;i++)
	{
		int result=0;
		for (int j=1;j<i;j++)
		{
			if (i%j==0)
			{
				result+=j;
			}
		}
		int sum=0;
		for (int k=1;k<result;k++)
		{
			if (result%k==0)
			{
				sum+=k;
			}
		}
		if (sum==i && i<result)
		{
			cout<<i<<"--"<<result<<"  ";
			num++;
			if (num%5==0)
				cout<<endl;
		}

	}
	cout<<"\ntotal:"<<num<<endl;	
}
//------------------------------//
void test27()
{
	cout<<0<<" ";
	int num,count,result;
	for (int i=1;i<200000;i++)
	{
		num=1;
		count=0;
		int temp=i;
		while (temp)
		{
			num*=10;
			temp/=10;
			count++;
		}
		result=0;
		int x=num;
		int y=i;
		for (int j=0;j<count;j++)
		{
			result=(result+(i%x)*(y%10)*(int)pow(10,j))%num;
			x/=10;
			y/=10;
		}
		if (result==i)
		{
			cout<<i<<" ";
		}
	}
	cout<<endl;

}
//------------------------------//
void test28()
{
	int n,m,temp;
	int num=0;
	for (int i=1;i<256;i++)
	{
		temp=n=i*i;
		m=0;
		while (temp)
		{
			m=m*10+temp%10;
			temp/=10;
		}
		if (m==n)
		{
			cout<<i<<" "<<i*i<<endl;
			num++;
		}
	}
	cout<<"total:"<<num<<endl;	
}
//------------------------------//
void test29()
{
	int temp,num=0;
	for (int i=1000;i<10000;i++)
	{
		temp=(i/1000+i/10%10)*10+i/100%10+i%10;
		if (temp*temp==i)
		{
			cout<<i<<endl;
			num++;
		}
	}
	cout<<"total:"<<num<<endl;
}

