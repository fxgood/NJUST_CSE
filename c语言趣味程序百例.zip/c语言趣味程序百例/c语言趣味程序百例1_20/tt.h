#pragma  once
#include <IOSTREAM>
#include <cmath>
#include <VECTOR>
#include <IOMANIP>
#include <vector>
#include <string>
using namespace std;

void test1();
void test4();
void test5();
void test6();
void test7();
void test8();
int jiecheng(int n);
int fun(int m,int n);
void test9();
void newfun(int n);
void test10();
void printb(int x,int n);
void newtest10();

int IsLeap(int n);
void test11();
void test12();
void test13();
void test14();
void test15();
void test16();
void test17();
void test18();
void newtest18();
void test19();
void test20();

void test21();
void test22();
void test23();
void newtest23();
void test24();
void test25();
void test26();
void test27();
void test28();
void test29();

int issushu(int n);
void test30();
void newtest30();
void test31();
void test32();
void newtest32();
void test33();
void test34();
int isPrime(int g_isPrime[],int i);
void Findlt(int k,const int N,int nLoop[],int bUsed[],int g_isPrime[]);
void newtest34();

bool IsReverse(int n);
bool IsRever_new(int n);
bool Judge(int a,int b,int c,int d);
void test35();
void test36();
void newtest36();
void test37();
void test38();
void test39();
void test40();

void test41();
int max(int m,int n);
int GCD(int m,int n);
int LCM(int m,int n);
void test42();
void test43();
void test44();
void newtest44();
int satify(int n);
int mysatify(int a,int b,int c);
void test45();
void newtest45();
int judeg46(int j,int n);
void test46();

void display58(vector<int>&v,int n);
void test58();

int judge59(int a,int b,int c,int d);
void test59();

int judge60(int a,int b,int c);
void test60();
void newtest60();
void mynewtest60();
int newjudge60(int a,int b,int c,int d);
void mynewtest60_4();
void test61();
//��������
void mycount();
//�ַ�������
typedef struct stu{
	string str;
	int num;
}ss;
void zqcstring();