#include "tt.h"
//------------------------------//
int issushu(int n)
{
	if (n<2)
		return 0;
	if (n==2)
		return 1;
	for (int i=2;i<(int)sqrt(n)+1;i++)
		if (n%i==0)
			return 0;
	return 1;
}
void test30()
{
	int num=0;
	for (int i=1;i<1000;i++)
	{
		if (issushu(i))
		{
			cout<<setw(3)<<i<<" ";
			num++;
			if(num%15==0)
				cout<<endl;
		}
	}
	cout<<"\ntotal:"<<num<<endl;
}
void newtest30()
{
	for (int i=2;;i++)
	{
		for (int j=0;j<10;j++)
		{
			if (issushu(i+j))
				break;
		}
		if (j==10)
		{
			for ( j=0;j<10;j++)
			{
				cout<<i+j<<" ";
			}
			cout<<endl;
			return;
		}
	}
}
//------------------------------//
void test31()
{	
	int m,n;
	cin>>m>>n;
	int num=0;
	for (int i=m;i<=n;i+=2)
	{
		for (int j=2;j<i;j++)
		{
			if (issushu(j)&&issushu(i-j))
			{
				cout<<i<<"="<<j<<"+"<<i-j<<" ";
				num++;
				if (num%5==0)
				{
					cout<<endl;
				}
				break;
			}
		}
	}
}
//------------------------------//
void test32()
{
	int result,temp,num=0;
	for (int i=1000;i<10000;i++)
	{
			temp=i;
			result=0;
			while(temp)
			{
				result=result*10+temp%10;
				temp/=10;
			}
			if (issushu(i)&&issushu(result)&& i<=result)
			{
				cout<<i<<" ";
				num++;
				if (num%5==0)
					cout<<endl;
			}
	}
	cout<<"\ntotal:"<<num<<endl;
}
void newtest32()
{
	int num=0;
	for (int i=2;i<1000;i++)
	{
		if (issushu(i)&&issushu(i+2))
		{
			cout<<i<<"��"<<i+2<<"Ϊ��������"<<endl;
			num++;
		}
	}
	cout<<"total:"<<num<<endl;
}
//------------------------------//
void test33()
{
	int temp,result;
	int num=0;
	for (int i=2;i<1000;i++)
	{
		temp=i;
		result=0;
		while(temp)
		{
			result=result*10+temp%10;
			temp/=10;
		}
		if (issushu(i)&&(result==i))
		{
			cout<<i<<" ";
			num++;
			if (num%5==0)
					cout<<endl;
		}
	}
	cout<<"\ntotal:"<<num<<endl;
}
//------------------------------//
void test34()
{
	for (int i=2;i<1994-1898;i++)
	{
		if (issushu(i)&&issushu(i+1898))
		{
			cout<<i<<"--"<<i+1898;
			cout<<endl;
		}
	}
}

int isPrime(int g_isPrime[],int i)
{
	return g_isPrime[i];
}
void Findlt(int k,const int N,int nLoop[],int bUsed[],int g_isPrime[])
{
	int i;
	if (k==N)
	{
		if (isPrime(g_isPrime,nLoop[0]+nLoop[N-1]))
		{
			for (i=0;i<N;i++)
				cout<<nLoop[i]<<" ";
			cout<<endl;
		}
		return;
	}
	for (i=1;i<=N;i++)
	{
		if(!bUsed[i] && isPrime(g_isPrime,i+nLoop[k-1]))
		{
			bUsed[i]=true;
			nLoop[k]=i;
			Findlt(k+1,N,nLoop,bUsed,g_isPrime);
			bUsed[i]=false;
		}
	}
}
void newtest34() 
{
	const int N=20;
	int nLoop[N+1];
	int g_Count=0;
	int bUsed[N+1];
	int g_isPrime[2*N]={
		0,0,2,3,0,5,0,7,0,0,
		0,11,0,13,0,0,0,17,0,19,
		0,0,0,23,0,0,0,0,0,29,
		0,31,0,0,0,0,0,37,0,0};
	for (int i=0;i<N+1;i++)
	{
		bUsed[i]=false;
	}
	nLoop[0]=1;
	bUsed[1]=true;
	Findlt(1,N,nLoop,bUsed,g_isPrime);
}
//------------------------------//
bool IsReverse(int n)
{
	int temp=n;
	int result=0;
	while (temp)
	{
		result=result*10+temp%10;
		temp/=10;
	}
	if (issushu(n)&&issushu(result))
		return true;
	return false;
}
bool IsRever_new(int n)
{
	int temp=n;
	if (!IsReverse(n))
		return 0;
	while (temp)
	{
		if (temp%10==2 ||temp%10==4 || temp%10==6 ||temp%10==8||temp%10==5 ||temp%10==0)
			return 0;
		temp/=10;
	}
	return 1;
}
bool Judge(int a,int b,int c,int d)
{
	//�ж�����
	int a1,b1,c1,d1;
	a1=(a/1000)*1000+(b/1000)*100+(c/1000)*10+(d/1000);
	b1=(a/100%10)*1000+(b/100%10)*100+(c/100%10)*10+(d/100%10);
	c1=(a/10%10)*1000+(b/10%10)*100+(c/10%10)*10+(d/10%10);
	d1=(a%10)*1000+(b%10)*100+(c%10)*10+(d%10);
	if (!IsReverse(a1) || !IsReverse(b1) || !IsReverse(c1) || !IsReverse(d1))
		return 0;
	int e,f;
	e=a/1000*1000+(b/100%10)*100+(c/10%10)*10+(d%10);
	f=d/1000*1000+(c/100%10)*100+(b/10%10)*10+(a%10);
	if (IsReverse(e)&&IsReverse(f))
	{
		return 1;
	}
	return 0;
}
void test35()
{
	vector<int>v1;//��ŵڶ����п�ѡ��Χ
	vector<int>v2;//��ŵ�һ���п�ѡ��Χ

	int num1=0;
	int num2=0;
	for (int i=1000;i<10000;i++)
	{
		if (IsReverse(i))
		{
			v1.push_back(i);
			num1++;
		}
		if (IsRever_new(i))
		{
			v2.push_back(i);
			num2++;
		}
	}
	int a,b,c,d,count=0;;
	for (i=0;i<num2;i++)
		for (int j=0;j<num1;j++)
			for (int k=0;k<num1;k++)
				for (int l=0;l<num2;l++)
				{
					a=v2[i],b=v1[j];
					c=v1[k],d=v2[l];
					if(Judge(a,b,c,d))
					{
						cout<<"NUM["<<count<<"]:"<<endl;
						cout<<a<<endl;
						cout<<b<<endl;
						cout<<c<<endl;
						cout<<d<<endl<<endl;
						count++;
					}

				}
	cout<<"total:"<<count<<endl;
}

//------------------------------//
void test36()
{
	int k;
	for (int i=0;i<=20;i++)
		for (int j=0;j<=33;j++)
		{
			k=100-i-j;
			if (k%3==0 && 5*i+3*j+k/3==100)
				cout<<"i="<<i<<" j="<<j<<" k="<<k<<endl;
		}
}
void newtest36()
{
	int k;
	for (int i=0;i<=33;i++)
		for (int j=0;j<=50;j++)
		{
			k=100-i-j;
			if (3*i+2*j+k==100)
				cout<<"i="<<i<<" j="<<j<<" k="<<k<<endl;
		}
}
//------------------------------//
void test37()
{
	int k;
	for (int i=0;;i++)
	{
		k=7*i;
		if (k%2==1 && k%3==2 && k%4==3 && k%5==4 && k%6==5)
		{
			cout<<k<<endl;
			break;
		}
	}

}
//------------------------------//
void test38()
{
	for (int i=0;i<=100;i++)
		for (int j=0;j<=50;j++)
			for (int k=0;k<=20;k++)
				if (i+2*j+5*k==100)
					cout<<"i="<<i<<" j="<<j<<" k="<<k<<endl;
}
//------------------------------//
void test39()
{
	int i,j;
	for ( i=0;i<=6;i++)
		for ( j=0;j<=13;j++)
			if (4*i+2*j==26  && (i-j)*i*(i+j)*(i+2*j)==880)
			{
				cout<<i<<" "<<j<<endl;
				for (int k=0;k<20;k++)
					cout<<i-j+k*j<<" ";
				cout<<endl;
				return;
			}
}
//------------------------------//
void test40()
{
	for (int i=0;i<=3;i++)
		for (int j=0;j<=3;j++)
			for(int k=0;k<=6;k++)
				if (i+j+k==8)
					cout<<"i="<<i<<" j="<<j<<" k="<<k<<endl;

}

//------------------------------//
void test41()
{
	int i,j;
	for(i=0;i<=10;i++)
		for(j=0;j<=20;j++)
			if(2*i+j==20)
				cout<<"i="<<i<<" j="<<j<<" k="<<30-i-j<<endl;
}
//------------------------------//
int max(int m,int n)
{
	return ((m>n)?m:n);
}
int GCD(int m,int n)
{
	int temp;
	while (m!=n)
	{
		temp=m;
		m=abs(m-n);
		n=temp+n-max(temp,n);
	}
	return m;
}
int LCM(int m,int n)
{
	return m*n/GCD(m,n);
}
void test42()
{
	int m,n;
	cin>>m>>n;
	cout<<"���Լ��:"<<GCD(m,n)<<"  ��С������:"<<LCM(m,n)<<endl;
}
//------------------------------//
void test43()
{
	for (int i=3;;i+=2)
	{
		int flag=1;
		for (int j=10;j>2&&flag;j--)
		{
			if (!(i%j==j-1))
			{
				flag=0;
			}
		}
		if (j==2)
			break;
	}
	cout<<i<<endl;
}
//------------------------------//
void test44()
{
	int a,b,c,d;
	scanf("%d/%d",&a,&b);
	scanf("%d/%d",&c,&d);
	int m=LCM(b,d)/b*a;
	int n=LCM(b,d)/d*c;
	if (m>n)
		cout<<a<<"/"<<b<<">"<<c<<"/"<<d<<endl;
	else if(m<n)
		cout<<a<<"/"<<b<<"<"<<c<<"/"<<d<<endl;
	else
		cout<<a<<"/"<<b<<"="<<c<<"/"<<d<<endl;
	
}
//------------------------------//
void newtest44()
{
	int temp,s;
	for (int p=2;p<=4;p++)
	{
		for (int q=p;q<=6;q++)
		{
			for (int r=q;r<=12;r++)
			{
				 temp=p*q*r-p*q-p*r-q*r;
				 if (temp==0)
					continue;
				 s=p*q*r/temp;
				if (p*q*r%temp==0 && s>=r)
				{
					cout<<"1/"<<p<<"+1/"<<q<<"+1/"<<r<<"+1/"<<s<<"=1"<<endl;
				}
			}
		}
	}

}
//------------------------------//
int satify(int n)
{
	vector<int>v;
	v.resize(10);
	for (int i=0;i<10;i++)
		v[i]=0;
	int num=0;
	while(n)
	{
		v[n%10]++;
		num++;
		n/=10;
	}
	for (i=0;i<num;i++)
	{
		if (v[i]>1)
			return 0;
	}
	return 1;
}
int mysatify(int a,int b,int c)
{
	vector<int>v;
	v.resize(10);
	while(a)
	{
		v[a%10]++;
		a/=10;
	}
	while(b)
	{
		v[b%10]++;
		b/=10;
	}
	while(c)
	{
		v[c%10]++;
		c/=10;
	}
	int sum=0;
	for (int i=1;i<10;i++)
	{
		if (v[i]>1)
			return 0;
		sum+=v[i];
	}
	if (sum==9)
		return 1;
	return 0;
}
void test45()
{
	int result,a,b;
	cin>>result;
	int i,j,k,l,m,n;
	int num=0;
	//��ʽһ
	for ( i=2;i<10;i++)
		for ( j=1;j<10;j++)
			for ( k=1;k<10;k++)
				for ( l=1;l<10;l++)
					for ( m=1;m<10;m++)
					{
						a=1000*j+100*k+10*l+m;//����
						b=a/(result-i);//��ĸ
						if (satify(a) && (a%(result-i)==0) && satify(b) && b>1000 && b<9990)
						{
							if (mysatify(i,a,b))
							{
								num++;
								cout<<"[NUM"<<num<<"]  "<<i<<"+"<<a<<"/"<<b<<"="<<result<<endl;
							}
							
						}
						
					}
	//��ʽ��
	for (i=2;i<10;i++)
	{
		for (j=1;j<10;j++)
		{
			for (k=1;k<10;k++)
			{
				for (l=1;l<10;l++)
				{
					for (m=1;m<10;m++)
					{
						for (n=1;n<10;n++)
						{
							a=10000*j+1000*k+100*l+10*m+n;
							b=a/(result-i);
							if (satify(a) && (a%(result-i)==0) && satify(b) && b>100 && b<990)
							{
								if (mysatify(i,a,b))
								{
									num++;
									cout<<"[NUM"<<num<<"]  "<<i<<"+"<<a<<"/"<<b<<"="<<result<<endl;
								}
								
							}

						}
					}
				}
			}
		}
	}
	//��ʽ��
	int temp;
	for (i=2;i<10;i++)
	{
		for (j=1;j<10;j++)
		{
			for (k=1;k<10;k++)
			{
				for (l=1;l<10;l++)
				{
					for (m=1;m<10;m++)
					{
						for (n=1;n<10;n++)
						{
							temp=i*10+j;
							a=1000*k+100*l+10*m+n;
							b=a/(result-temp);
							if (satify(temp) && satify(a) && (a%(result-temp)==0) && satify(b) && b>100 && b<990)
							{
								if (mysatify(temp,a,b))
								{
									num++;
									cout<<"[NUM"<<num<<"]  "<<temp<<"+"<<a<<"/"<<b<<"="<<result<<endl;
								}
								
							}

						}
					}
				}
			}
		}
	}	
}
//------------------------------//
void newtest45()
{
	int a,b;
	cin>>a>>b;
	int i;
	cout<<a<<"/"<<b<<"=";
	if (b%a==0)
	{
		cout<<"1/"<<b/a<<endl;
		return;
	}
	while (1)
	{
		i=2;
		while (a*i<b)     
			i++;
		cout<<"1/"<<i<<"+";
		//���¼���a,b
		int temp=LCM(b,i);
		a=a*(temp/b)-temp/i;
		b=temp;
		if (b%a==0)
		{
			cout<<"1/"<<b/a<<endl;
			break;
		}
	}	
}
//------------------------------//
int judeg46(int j,int n)
{
	if (n%j==0)
	{
		return 1;
	}
	else
		return 0;
}
void test46()
{
	int n;
	cin>>n;
	cout<<"1/"<<n<<" ";
	int flag;
	for (int i=2;i<n;i++)
	{
		flag=0;
		for (int j=2;j<=i;j++)
		{
			if (judeg46(j,i)&&judeg46(j,n))
			{
				flag=1;
				break;
			}
		}
		if(!flag)
			cout<<i<<"/"<<n<<" ";
	}
	cout<<endl;
}
//------------------------------//
void display58(vector<int>&v,int n)
{
	for (int i=1;i<n;i++)
		cout<<v[i]<<" ";
	cout<<endl;
	for (i=1;i<n;i++)
		v[i-1]=v[i];
	v[i-1]=v[0];
}
void test58()
{
	int n;
	cin>>n;
	vector<int>v;
	v.resize(n+1);
	for (int j=0;j<n;j++)
	{
		for (int i=1;i<n+1;i++)
			v[i]=((i+j)>6?(i+j-6):(i+j));

		for (i=0;i<n;i++)
		display58(v,n+1);
		cout<<endl;
	}	
}
//------------------------------//
int judge59(int a,int b,int c,int d)
{
	vector<int>v;
	v.resize(6);
	for (int i=0;i<6;i++)
		v[i]=0;
	v[a]++;
	v[b]++;
	v[c]++;
	v[d]++;
	for ( i=2;i<6;i++)
		if (v[i]>1)
			return 0;
	return 1;
}
void test59()
{
	for (int i=2;i<4;i++)
		for (int j=2;j<6;j++)
			for (int k=2;k<6;k++)
				for (int l=4;l<6;l++)
					if (j>i && l>i && l>k && judge59(i,j,k,l))
					{
						cout<<1<<" "<<i<<" "<<j<<endl;
						cout<<k<<" "<<l<<" "<<6<<endl;
						cout<<endl;
					}
}
//------------------------------//
//------------------------------//
int judge60(int a,int b,int c)
{
	vector<int>v;
	v.resize(10);
	for (int i=0;i<10;i++)
		v[i]=0;
	while (a)
	{
		v[a%10]++;
		a/=10;
	}
	while (b)
	{
		v[b%10]++;
		b/=10;
	}
	while (c)
	{
		v[c%10]++;
		c/=10;
	}
	for ( i=1;i<10;i++)
		if (v[i]!=1)
			return 0;
	return 1;
}
void test60()
{
	int j,k;
	for (int i=123;i<333;i++)
	{
		j=i*2;
		k=i*3;
		if (judge60(i,j,k))
			cout<<i<<" "<<j<<" "<<k<<endl;
	}
}
void newtest60()
{
	int k;
	for (int i=1234;i<9000;i++)
		for (int j=1;j<9;j++)
		{
			k=i*j;
			if ( k<10000 &&judge60(i,j,k) )
				cout<<i<<"*"<<j<<"="<<k<<endl;
		}
}
void mynewtest60()
{
	int k;
	for (int i=12;i<=98;i++)
		for (int j=123;j<=987;j++)
		{
			k=i*j;
			if ( k<10000 &&judge60(i,j,k) )
				cout<<i<<"*"<<j<<"="<<k<<endl;
		}
}
int newjudge60(int a,int b,int c,int d)
{
	vector<int>v;
	v.resize(10);
	for (int i=0;i<10;i++)
		v[i]=0;
	while (a)
	{
		v[a%10]++;
		a/=10;
	}
	while (b)
	{
		v[b%10]++;
		b/=10;
	}
	while (c)
	{
		v[c%10]++;
		c/=10;
	}
	while (d)
	{
		v[d%10]++;
		d/=10;
	}
	for ( i=1;i<10;i++)
		if (v[i]!=1)
			return 0;
	return 1;

}
void mynewtest60_4()
{
	for (int i=12;i<=98;i++)
		for (int j=123;j<=987;j++)
			for (int k=123;k<=987;k++)
				for (int l=1;l<=9;l++)
				{
					if (i*j==l*k && newjudge60(i,j,k,l))
					{
						cout<<i<<"*"<<j<<"="<<k<<"*"<<l<<endl;
					}
				}
}
void test61()
{
	for(int i=11;i<32;i++)
		for(int j=11;j<32;j++)
		{
			for (int k=11;k<32;k++)
			{
				if (judge60(i*i,j*j,k*k) && i<j && j<k)
				{
					cout<<i*i<<" "<<j*j<<" "<<k*k<<endl;
				}
			}
		}
}
void mycount()
{
	int a,b,i,temp,count,left,right;
	while(cin>>a>>b && a!=0 && b!=0)
	{
		count=0;
		left=((a<b)?a:b);
		right=a+b-left;
		for (i=left;i<=right;i++)
		{
			temp=i;
			while (temp)
			{
				if(temp%10==1)
					count++;
				temp/=10;
			}
		}
		cout<<count<<endl;
	}
}
//�ַ�������
void zqcstring()
{
	int m;
	string strstr;
	int k=0;
	while(cin>>m && m!=0)
	{
		//��ʼ���ṹ������
		vector<ss>v;
		v.resize(m);
		int i,j;
		for ( i=0;i<m;i++)
		{
			v[i].str="";
			v[i].num=0;
		}
		int count=0;
		for (i=0;i<m;i++)
		{
			cin>>strstr;
			for( j=0;j<m;j++)
			{
				if(v[j].str==strstr)//�ҵ�
				{
					v[j].num++;
					break;
				}
			}
			if (j==m)
			{
				v[count].str=strstr;
				v[count].num++;
				count++;
			}
		}
		cout<<"ͳ�ƣ�"<<endl;
		for (i=0;i<count;i++)
			cout<<v[i].str<<" "<<v[i].num<<endl;
		int sum=0;
		int zqccount=0;
		cout<<"case:"<<++k<<endl;
		for ( i=1;i<=m;i++)
		{
			zqccount=0;
			for (j=0;j<count;j++)
			{
				if (v[j].num==i)
				{
					sum+=i;
					zqccount++;
				}
			}
			if (zqccount>0)
				cout<<i<<" "<<zqccount<<endl;
			if (sum==m)
				break;

		}
		v.clear();
	}

}